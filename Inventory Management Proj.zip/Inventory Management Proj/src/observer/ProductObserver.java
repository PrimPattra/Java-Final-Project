package observer;

public interface ProductObserver {
    void update(String message);
}
